<html>
	<title>Form Login </title>
	<head>
		<table width="300" align="center">
			<form  method="POST" action="cek_login.php">
			<tr>
 
				<td colspan="3"><strong>Form Login</strong></td>
			</tr>
			<tr>
				<td>Username</td>
				<td>:</td>
				<td><input name="username" type="text" id="username"/>
				</td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password" id="password"/></td>
			</tr>
			<tr>
				<td><button type="submit" name="button" value="login"  class="btn btn-block btn-danger">Login</button></td>
			</tr>
		</form>
		</table>
	</head>
</html>