<?php 
include "lib/koneksi2.php"; 
include "header.php"; 
 ?>
 
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-12">
                        <h1 class="mt-12">Dashboard</h1>
                        <ol class="breadcrumb mb-12">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-12">
                            
                                <font size="12px"><a>fsfsf</a></font><br>
                                <font size="4px"><a>fsfsf </a><a>fsfsf</a></font>
                                <font size="5px"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></font>
                            
                            </div>
                        </div>
                        <hr>
                        
                    </div>
                </main>

<?php 
include "footer.php"; 
 ?>