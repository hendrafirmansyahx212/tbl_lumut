<?php 

$server = "localhost";
$username = "root";
$password = ""; 
$database =  "tbl_lumut";

$baseUrl = 'http://localhost/tbl-lumut/';
$koneksi = mysqli_connect($server,$username,$password,$database);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL". mysqli_connect_errno();
    exit();
}



?>
