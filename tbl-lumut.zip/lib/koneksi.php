

<?php

$baseUrl = 'http://localhost/tbl-lumut/';
class Database {

    
    private $koneksi;
    private $query;
    private $results = [];
    public function __construct()
    {
        $this->connect();
    }
    public function connect(){
	    $this->koneksi = mysqli_connect('127.0.0.1','root','','tbl_lumut');
	    if(mysqli_connect_error()){
            die("Database failed to connect ".mysqli_connect_error().mysqli_connect_errno());
        }
    }
    public function query($sql){
         return $this->query = mysqli_query($this->koneksi,$sql) or die(mysqli_error($this->koneksi));
    }
    public function close(){
        mysqli_close($this->koneksi);
    }
    public function fetch(){
     if(gettype($this->query) == 'boolean'){
        return $this->query;
     }
     if($this->query->num_rows > 0){
         while ($row = mysqli_fetch_assoc($this->query)){
             array_push($this->results,(object)$row);
         }
     }
     return $this->results;
    }
    
}
  class koneksi
  {

    private $_host = 'localhost';
    private $_username = 'root';
    private $_password = '';
    private $_database = 'tbl_lumut';

    protected $conn;

    public function __construct()
    {
        if (!isset($this->connection)) {

            $this->conn = new mysqli($this->_host, $this->_username, $this->_password, $this->_database);

            if (!$this->conn) {
                echo 'Cannot to database server';
                exit;
            }
        }

        return $this->conn;
    }
  }

?>